package golfProject;
/*
 * Name: Zhaozhou Lyu
 * NetID: zlyu2
 * Assignment number: Project02
 * Lab: TR6:15PM
 * 
 * I did not collaborate with anyone on this assignment.
 */
/**
 * This class calls the methods in other classes.
 * @author georgelyu
 *
 */

public class golf_test {

	public static void main(String[] args) {
		
		//Set up the instances variables for game and call the method in game
		game g=new game();
		game.gameMain();
		
		
	}
}

